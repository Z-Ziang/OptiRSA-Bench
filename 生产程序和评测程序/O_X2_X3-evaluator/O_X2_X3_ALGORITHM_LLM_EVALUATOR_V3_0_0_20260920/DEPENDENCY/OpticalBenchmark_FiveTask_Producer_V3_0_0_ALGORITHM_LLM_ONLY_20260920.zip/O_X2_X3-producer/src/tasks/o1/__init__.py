"""O-family task module."""
